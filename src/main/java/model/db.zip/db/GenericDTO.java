/**
 * 
 */
package model.db;

/**
 * @author acil
 *
 */
public class GenericDTO {

	/**
	 * 
	 */
	public GenericDTO() {
		// Just for enabling creating objects without any mandatory parameters
	}

}
