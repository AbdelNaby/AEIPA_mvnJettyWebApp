/**
 * 
 */
package model.db;

/**
 * @author acil
 *
 */
public class SeqDatasetResult {
	private String  datasetSeqName;
	private String  tPR ;
	private String  tNR ;
	private String  fNR ;
	private String  fPR ;
	/**
	 * 
	 */
	public SeqDatasetResult() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the datasetSeqName
	 */
	public String getDatasetSeqName() {
		return datasetSeqName;
	}
	/**
	 * @param datasetSeqName the datasetSeqName to set
	 */
	public void setDatasetSeqName(String datasetSeqName) {
		this.datasetSeqName = datasetSeqName;
	}
	/**
	 * @return the tPR
	 */
	public String gettPR() {
		return tPR;
	}
	/**
	 * @param tPR the tPR to set
	 */
	public void settPR(String tPR) {
		this.tPR = tPR;
	}
	/**
	 * @return the tNR
	 */
	public String gettNR() {
		return tNR;
	}
	/**
	 * @param tNR the tNR to set
	 */
	public void settNR(String tNR) {
		this.tNR = tNR;
	}
	/**
	 * @return the fNR
	 */
	public String getfNR() {
		return fNR;
	}
	/**
	 * @param fNR the fNR to set
	 */
	public void setfNR(String fNR) {
		this.fNR = fNR;
	}
	/**
	 * @return the fPR
	 */
	public String getfPR() {
		return fPR;
	}
	/**
	 * @param fPR the fPR to set
	 */
	public void setfPR(String fPR) {
		this.fPR = fPR;
	}

}
