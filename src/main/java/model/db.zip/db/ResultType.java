/**
 * 
 */
package model.db;

/**
 * @author acil
 *
 */
public enum ResultType {
	BOUNDING_BOX, LABELLED_BOUNDING_BOX
}


//public enum choices {a1, a2, b1, b2};
//public static boolean contains(String test) {
//    for (Choice c : Choice.values()) {
//        if (c.name().equals(test)) {
//            return true;
//        }
//    }
//    return false;
//}